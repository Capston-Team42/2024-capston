package com.example.digital_wardrobe.controller;

import com.example.digital_wardrobe.model.Item;
import com.example.digital_wardrobe.service.ItemService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/items")
public class ItemController {

    private final ItemService itemService;

    public ItemController(ItemService itemService) {
        this.itemService = itemService;
    }

    // ✅ GPT 태그 분석용
    @PostMapping("/analyze")
    public ResponseEntity<Map<String, Object>> analyzeImage(@RequestParam("file") MultipartFile file) {
        Map<String, Object> result = itemService.analyzeImage(file);
        return ResponseEntity.ok(result);
    }

    // ✅ 아이템 생성
    @PostMapping("/create")
    public ResponseEntity<Item> createItem(
            @RequestBody Item item) {
        Item createdItem = itemService.createItem(item);
        return ResponseEntity.ok(createdItem);
    }
    // ✅ 아이템 수정
    @PutMapping("/update/{id}")
    public ResponseEntity<Item> updateItem(
            @PathVariable String id,
            @RequestPart(value = "file", required = false) MultipartFile file,
            @RequestPart("item") String itemJson) {

        try {
            ObjectMapper mapper = new ObjectMapper();
            Item updatedItem = mapper.readValue(itemJson, Item.class);
            return itemService.updateItem(id, updatedItem, file)
                    .map(ResponseEntity::ok)
                    .orElse(ResponseEntity.notFound().build());
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }


    // ✅ 옷장별 아이템 목록 조회
    @GetMapping("/wardrobe/{wardrobeId}")
    public ResponseEntity<List<Item>> getItemsByWardrobeId(@PathVariable String wardrobeId) {
        return ResponseEntity.ok(itemService.getItemsByWardrobeId(wardrobeId));
    }

    // ✅ 아이템 삭제
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteItem(@PathVariable String id) {
        itemService.deleteItem(id);
        return ResponseEntity.ok().build();
    }
}

