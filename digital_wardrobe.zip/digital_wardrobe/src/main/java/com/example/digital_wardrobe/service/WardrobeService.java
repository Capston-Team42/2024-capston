package com.example.digital_wardrobe.service;

import com.example.digital_wardrobe.model.Wardrobe;
import com.example.digital_wardrobe.repository.WardrobeRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class WardrobeService {

    private final WardrobeRepository wardrobeRepository;

    public WardrobeService(WardrobeRepository wardrobeRepository) {
        this.wardrobeRepository = wardrobeRepository;
    }

    public List<Wardrobe> getWardrobesByUserId(String userId) {
        return wardrobeRepository.findByUserId(userId);
    }

    public Wardrobe createWardrobe(Wardrobe wardrobe) {
        return wardrobeRepository.save(wardrobe);
    }

    public void deleteWardrobe(String id) {
        wardrobeRepository.deleteById(id);
    }
}
