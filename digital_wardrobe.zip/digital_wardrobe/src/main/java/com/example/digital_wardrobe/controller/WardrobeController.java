package com.example.digital_wardrobe.controller;

import com.example.digital_wardrobe.model.Wardrobe;
import com.example.digital_wardrobe.service.WardrobeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.aggregation.VariableOperators.Map;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/wardrobes")
public class WardrobeController {

    private final WardrobeService wardrobeService;

    @Autowired
    public WardrobeController(WardrobeService wardrobeService) {
        this.wardrobeService = wardrobeService;
    }

    // 🔹 특정 유저의 모든 옷장 조회
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Wardrobe>> getWardrobesByUserId(@PathVariable String userId) {
        List<Wardrobe> wardrobes = wardrobeService.getWardrobesByUserId(userId);
        return ResponseEntity.ok(wardrobes);
    }

    // 🔹 옷장 생성
    @PostMapping
    public ResponseEntity<Wardrobe> createWardrobe(@RequestBody Wardrobe wardrobe) {
        Wardrobe saved = wardrobeService.createWardrobe(wardrobe);
        return ResponseEntity.ok(saved);
    }

    // 🔹 옷장 삭제
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteWardrobe(@PathVariable String id) {
        wardrobeService.deleteWardrobe(id);
        return ResponseEntity.ok("Wardrobe deleted");
    }
    

}
