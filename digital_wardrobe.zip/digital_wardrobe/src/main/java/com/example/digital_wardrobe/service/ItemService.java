package com.example.digital_wardrobe.service;

import com.example.digital_wardrobe.model.Item;

import com.example.digital_wardrobe.repository.ItemRepository;
import org.springframework.stereotype.Service;

import java.lang.reflect.Method;
import java.util.*;
import java.util.stream.Collectors;
import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;


@Service
public class ItemService {

    private final ItemRepository itemRepository;
    private final EmbeddingService embeddingService;
    private final GptTaggingService gptService;
    
    private final S3Service s3Service;

    public ItemService(ItemRepository itemRepository, EmbeddingService embeddingService, S3Service s3Service, GptTaggingService gptService) {
        this.itemRepository = itemRepository;
        this.embeddingService = embeddingService;
        this.s3Service = s3Service;
        this.gptService = gptService;
    }

    public List<Item> getItemsByWardrobeId(String wardrobeId) {
        return itemRepository.findByWardrobeId(wardrobeId);
    }
    public Map<String, Object> analyzeImage(MultipartFile multipartFile) {
        try {
            // 🔹 MultipartFile → File 변환
            File file = convertMultiPartToFile(multipartFile);

            // 🔹 S3 업로드
            String imageUrl = s3Service.uploadFile(file);

            // 🔹 임시 파일 삭제
            file.delete();

            // 🔹 GPT API 호출하여 태그 추출
            Map<String, Object> tagResult = gptService.extractTagsFromImage(imageUrl);  // 👉 너가 만든 GPT 호출 메서드 연결 필요

            return tagResult;  // 완전 깔끔하게 flat 구조 유지됨

        } catch (IOException e) {
            throw new RuntimeException("analyzeImage 실패: " + e.getMessage());
        }
    }


    public Item createItem(Item item) {
        // 🔹 임베딩 처리
        Map<String, List<String>> tagMap = new HashMap<>();
        tagMap.put("common", List.of("style", "tpo", "details", "vibe", "color", "pattern", "seasons", "texture", "thickness", "category"));
        tagMap.put("outer", List.of("fastening_method", "top_type", "sleeve_type", "fit"));
        tagMap.put("pants", List.of("pants_fit", "bottom_length_type"));
        tagMap.put("skirt", List.of("skirt_fit", "skirt_type"));
        tagMap.put("dress", List.of("neckline", "skirt_type", "sleeve_type","fit"));
        tagMap.put("top", List.of("top_type", "sleeve_type", "neckline", "fit"));


        String type = item.getType() != null ? item.getType().toLowerCase() : "";
        Set<String> applicableTags = new HashSet<>(tagMap.get("common"));

        if (type.equals("dress")) applicableTags.addAll(tagMap.get("dress"));
        else if (type.equals("pants")) applicableTags.addAll(tagMap.get("pants"));
        else if (type.equals("skirt")) applicableTags.addAll(tagMap.get("skirt"));
        else if (type.equals("top")) applicableTags.addAll(tagMap.get("top"));
        else if (type.equals("outer")) applicableTags.addAll(tagMap.get("outer"));

        for (String tag : applicableTags) {
            try {
                String camelTag = tag;
                String getterName = "get" + camelTag.substring(0, 1).toUpperCase() + camelTag.substring(1);
                Method getter = Item.class.getMethod(getterName);
                Object value = getter.invoke(item);

                if (value != null) {
                    List<Double> embedding;

                    if (value instanceof String strVal) {
                        embedding = embeddingService.generateEmbedding(List.of(strVal));
                    } else if (value instanceof List listVal) {
                        embedding = embeddingService.generateEmbedding((List<String>) listVal);
                    } else {
                        continue;
                    }

                    String setterName = "set" + camelTag.substring(0, 1).toUpperCase() + camelTag.substring(1) + "_embedding";
                    Method setter = Item.class.getMethod(setterName, List.class);
                    setter.invoke(item, embedding);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return itemRepository.save(item);
    }

    public void deleteItem(String id) {
        Optional<Item> optionalItem = itemRepository.findById(id);

        optionalItem.ifPresent(item -> {
            // 1. S3 이미지 삭제
            if (item.getImage_url() != null) {
                s3Service.deleteFile(item.getImage_url());  // ⬅️ 이미지 삭제 로직 추가
            }

            // 2. DB에서 아이템 삭제
            itemRepository.deleteById(id);
        });
    }

    public Optional<Item> updateItem(String id, Item updatedItem, MultipartFile multipartFile) {
        return itemRepository.findById(id).map(item -> {

            // ✅ 이미지 업로드 및 교체
            try {
                if (multipartFile != null && !multipartFile.isEmpty()) {
                    File file = convertMultiPartToFile(multipartFile);
                 // 💡 기존 이미지 URL 저장
                    String oldImageUrl = item.getImage_url();
                    // 💡 새 이미지 업로드
                    String imageUrl = s3Service.uploadFile(file);
                    // 💡 이전 이미지 삭제
                    if (oldImageUrl != null && !oldImageUrl.isEmpty()) {
                        s3Service.deleteFile(oldImageUrl);
                    }

                    item.setImage_url(imageUrl);
                    file.delete();

                } else if (updatedItem.getImage_url() != null) {
                    item.setImage_url(updatedItem.getImage_url());
                }
            } catch (IOException e) {
                throw new RuntimeException("이미지 업로드 실패: " + e.getMessage());
            }

            // ✅ 태그 설정용 Map
            Map<String, List<String>> tagMap = new HashMap<>();
            tagMap.put("common", List.of("style", "tpo", "details", "vibe", "color", "pattern", "seasons", "texture", "thickness", "category"));
            tagMap.put("outer", List.of("fastening_method", "top_type", "sleeve_type", "fit"));
            tagMap.put("pants", List.of("pants_fit", "bottom_length_type"));
            tagMap.put("skirt", List.of("skirt_fit", "skirt_type"));
            tagMap.put("dress", List.of("neckline", "skirt_type", "sleeve_type","fit"));
            tagMap.put("top", List.of("top_type", "sleeve_type", "neckline", "fit"));

            // ✅ type 기준으로 applicable 태그 설정
            String type = item.getType() != null ? item.getType().toLowerCase() : "";
            Set<String> applicableTags = new HashSet<>(tagMap.get("common"));

            if (type.equals("dress")) applicableTags.addAll(tagMap.get("dress"));
            else if (type.equals("pants")) applicableTags.addAll(tagMap.get("pants"));
            else if (type.equals("skirt")) applicableTags.addAll(tagMap.get("skirt"));
            else if (type.equals("top")) applicableTags.addAll(tagMap.get("top"));
            else if (type.equals("outer")) applicableTags.addAll(tagMap.get("outer"));

            // ✅ 태그별 업데이트 + 임베딩 재생성
            for (String tag : applicableTags) {
            	 String capitalizedTag = tag.substring(0, 1).toUpperCase() + tag.substring(1);
                try {
                    String camelTag = tag;
                    String getterName = "get" + camelTag.substring(0, 1).toUpperCase() + camelTag.substring(1);
                    Method getter = Item.class.getMethod(getterName);
                    Object value = getter.invoke(updatedItem);

                    if (value != null) {
                        List<Double> embedding;

                        if (value instanceof String strVal) {
                            embedding = embeddingService.generateEmbedding(List.of(strVal));
                        } else if (value instanceof List listVal) {
                            embedding = embeddingService.generateEmbedding((List<String>) listVal);
                        } else {
                            continue;
                        }

                        String setterName = "set" + camelTag.substring(0, 1).toUpperCase() + camelTag.substring(1) + "_embedding";
                        Method setter = Item.class.getMethod(setterName, List.class);
                        setter.invoke(item, embedding);

                        Class<?> paramType = (value instanceof List) ? List.class : String.class; 
                        Method itemSetter = Item.class.getMethod("set" + capitalizedTag, paramType); 
                        itemSetter.invoke(item, value);
                        itemSetter.invoke(item, value);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            return itemRepository.save(item);
        });
    }

    private File convertMultiPartToFile(MultipartFile multipartFile) throws IOException {
        File convFile = new File(multipartFile.getOriginalFilename());
        FileOutputStream fos = new FileOutputStream(convFile);
        fos.write(multipartFile.getBytes());
        fos.close();
        return convFile;
    }

}