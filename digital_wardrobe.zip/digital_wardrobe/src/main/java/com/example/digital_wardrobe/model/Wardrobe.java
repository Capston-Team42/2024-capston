package com.example.digital_wardrobe.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "UserWardrobe")
public class Wardrobe {
    @Id
    private String id;
    private String userId;
    private String wardrobeName;

    public Wardrobe() {}

    public Wardrobe(String userId, String wardrobeName) {
        this.userId = userId;
        this.wardrobeName = wardrobeName;
    }

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getUserId() {
        return userId;
    }
    public void setUserId(String userId) {
        this.userId = userId;
    }
    public String getWardrobeName() {
        return wardrobeName;
    }
    public void setWardrobeName(String wardrobeName) {
        this.wardrobeName = wardrobeName;
    }
}

