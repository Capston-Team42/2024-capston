package com.example.digital_wardrobe.service;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;


@Service
public class GptTaggingService {

    private final RestTemplate restTemplate = new RestTemplate();

    @Value("${openai.api.key}")
    private String apiKey;

    
    public Map<String, Object> extractTagsFromImage(String image_url) {
    	String prompt = """
    			You are a fashion tagging AI. Analyze the clothing item in the image and return the tags in the following JSON format.
    			Respond only with **RAW JSON**. **Start with '{' and end with '}'**. **Do not include ``json or ```**.

    			Return a **flat JSON object**, not a nested one.

    			- Include "image_url": "<input_image_url>" as the first field.

    			Then, determine the "type" of the clothing item:
    			One of the following: "outer", "top", "dress", "pants", "skirt"

    			Then, based on the type, return the corresponding tags as **top-level keys**, not under a "tags" field.

    			- Common to all types:
    			  "style": [ ... ],
    			  "tpo": [ ... ],
    			  "details": [ ... ],
    			  "vibe": [ ... ],
    			  "color": "...",
    			  "pattern": "...",
    			  "seasons": [ ... ],
    			  "texture": [ ... ],
    			  "thickness": [ ... ],
    			  "category": "..."

    			- Type-specific fields:
    			  For "outer":
    			    "fastening_method": "...",
    			    "top_type": "...",
    			    "sleeve_type": "...",
    			    "fit": [ ... ]

    			  For "top":
    			    "top_type": "...",
    			    "sleeve_type": "...",
    			    "neckline": "...",
    			    "fit": [ ... ],
    			    "isSimple": "yes" or "no"

    			  For "dress":
    			    "neckline": "...",
    			    "skirt_type": "...",
    			    "sleeve_type": "...",
    			    "fit": [ ... ]

    			  For "pants":
    			    "pants_fit": "...",
    			    "bottom_length_type": "..."

    			  For "skirt":
    			    "skirt_fit": "...",
    			    "skirt_type": "..."

    			⛔ IMPORTANT: For the following fields, choose ONLY ONE value from the predefined list below. Do NOT invent new values.

    			- For top:
    			  - "category": one of ["맨투맨", "후드 티셔츠", "셔츠/블라우스", "티셔츠", "니트"]
    			  - "sleeve_type": one of ["long sleeve", "short sleeve", "sleeveless"]
    			  - "isSimple": one of ["yes", "no"]

    			- For pants:
    			  - "category": one of ["데님 팬츠", "트레이닝 팬츠", "코튼 팬츠", "슬랙스", "레깅스", "오버올"]

    			- For outer:
    			  - "category": one of ["후드집업", "블루종/MA-1", "레더/라이더스 재킷", "카디건", "트러커 재킷", "슈트/블레이저 재킷", "스타디움 재킷", "나일론/코치 재킷", "아노락 재킷", "트레이닝 재킷", "코트", "사파리/헌팅 재킷", "패딩", "무스탕/퍼", "플리스/뽀글이"]
    			  - "sleeve_type": one of ["long sleeve", "short sleeve", "sleeveless"]

    			- For dress:
    			  - "category": one of ["미니원피스", "미디원피스", "맥시원피스"]

    			- For skirt:
    			  - "category": one of ["미니스커트", "미디스커트", "롱스커트"]
    			  - "skirt_type": one of ["pleated", "tiered", "wrap", "plain", "skirt pants"]

    			Respond in **valid flat JSON format**. Only include fields that are visually identifiable. Use **double quotes** for all keys and values. Do not include explanations.

    			image_url: %s
    			""".formatted(image_url);



        Map<String, Object> body = new HashMap<>();
        body.put("model", "gpt-4o");
        List<Map<String, Object>> contentList = List.of(
                Map.of("type", "text", "text", prompt),
                Map.of("type", "image_url", "image_url", Map.of("url", image_url))
            );

            Map<String, Object> message = Map.of(
                "role", "user",
                "content", contentList
            );

            body.put("messages", List.of(message));

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(apiKey);

        HttpEntity<Map<String, Object>> request = new HttpEntity<>(body, headers);

        ResponseEntity<Map> response = restTemplate.postForEntity(
                "https://api.openai.com/v1/chat/completions", request, Map.class
        );

        try {
            Map<String, Object> choices = (Map<String, Object>) ((List<?>) response.getBody().get("choices")).get(0);
            String content = (String) ((Map<?, ?>) choices.get("message")).get("content");

            // ✅ GPT 응답 원문 출력
            System.out.println("🧠 GPT 응답 원문:");
            System.out.println(content);

            // JSON 응답 문자열 → Map으로 파싱
            ObjectMapper mapper = new ObjectMapper();
            return mapper.readValue(content, Map.class);

        } catch (Exception e) {
        	// ✅ 파싱 실패 시에도 응답 출력
            System.out.println("❌ GPT 응답 파싱 실패! 응답 원문:");
            System.out.println(response);
            throw new RuntimeException("GPT 응답 파싱 실패: " + e.getMessage());

        }
    }
}
