package com.example.digital_wardrobe.repository;

import com.example.digital_wardrobe.model.UserInfo;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface UserInfoRepository extends MongoRepository<UserInfo, String> {
}
